//
//  ViewController.h
//  checking
//
//  Created by Zeeshan on 20/02/2017.
//  Copyright © 2017 Zeeshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *bottonview;
@property (weak, nonatomic) IBOutlet UIImageView *upperview;
@property (weak, nonatomic) IBOutlet UIImageView *lowerview;
@property(weak,nonatomic)IBOutlet UIImageView *bottomright;
@property(weak,nonatomic)IBOutlet UIImageView *bottomback;

@end

