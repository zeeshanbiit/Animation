//
//  ViewController.m
//  checking
//
//  Created by Zeeshan on 20/02/2017.
//  Copyright © 2017 Zeeshan. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize bottonview;
@synthesize upperview;
@synthesize lowerview;
@synthesize bottomright;
@synthesize bottomback;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewWillAppear:(BOOL)animated{
    CGRect basketTopFrame = self.upperview.frame;
    basketTopFrame.origin.y = -basketTopFrame.size.height;
    
    CGRect basketBottomFrame = self.lowerview.frame;
    basketBottomFrame.origin.y = self.view.bounds.size.height;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelay:1.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    self.upperview.frame = basketTopFrame;
    self.lowerview.frame = basketBottomFrame;
    
    [UIView commitAnimations];
}
-(void)viewDidAppear:(BOOL)animated{
    CGRect basketTopFrame = self.bottonview.frame;
    basketTopFrame.origin.x = -basketTopFrame.size.width;
    
    CGRect basketBottomFrame = self.bottomright.frame;
    basketBottomFrame.origin.x = self.view.bounds.size.width;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:3.0];
    [UIView setAnimationDelay:1.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    self.bottonview.frame = basketTopFrame;
    self.bottomright.frame = basketBottomFrame;
    
    [UIView commitAnimations];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:5.0];
    [UIView setAnimationDelay:5.0];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    
    
    self.bottomback.frame= CGRectMake(400, 0, 0, 0);
    [UIView commitAnimations];
    


  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
