//
//  AppDelegate.h
//  checking
//
//  Created by Zeeshan on 20/02/2017.
//  Copyright © 2017 Zeeshan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

